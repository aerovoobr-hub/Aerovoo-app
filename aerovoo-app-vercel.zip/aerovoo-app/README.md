# AeroVoo App

Web app de roteiros de viagem da AeroVoo.

## Como publicar no Vercel (passo a passo)

### Pré-requisitos
- Conta gratuita no GitHub (github.com)
- Conta gratuita no Vercel (vercel.com)

### Passo 1 — Subir para o GitHub
1. Acesse github.com e clique em "New repository"
2. Nome: `aerovoo-app` → clique em "Create repository"
3. No seu computador, descompacte este ZIP
4. Abra o terminal na pasta e execute:
```
git init
git add .
git commit -m "AeroVoo App"
git remote add origin https://github.com/SEU_USUARIO/aerovoo-app.git
git push -u origin main
```

### Passo 2 — Publicar no Vercel
1. Acesse vercel.com → clique em "Add New Project"
2. Conecte sua conta GitHub
3. Selecione o repositório `aerovoo-app`
4. Clique em "Deploy" — pronto!
5. Seu link será: https://aerovoo-app.vercel.app

### Passo 3 — Compartilhar com o cliente
Envie o link pelo WhatsApp:
"Olá! Seu roteiro de viagem está disponível no link abaixo.
No celular, abra o link → toque nos 3 pontinhos → Adicionar à tela inicial
Assim fica igual a um app! 🛫"

### Como personalizar para cada cliente
Edite o arquivo `src/App.js` e mude:
- `clientName` — Nome do cliente/família
- `destination` — Destino da viagem  
- `dates` — Datas da viagem
- `code` — Código da reserva
- `isDisney` — true para viagens Disney
- `days` — Array com os dias e eventos da viagem
- `documents` — Lista de documentos

